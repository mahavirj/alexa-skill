A pure-Python implementation of ASN.1 types and DER/BER/CER codecs (X.208).


